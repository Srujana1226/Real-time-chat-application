import ChatContainer from "./components/ChatContainer"
import UserLogin from "./components/UserLogin"


function App() {

  return (
    <div className="App">
    <ChatContainer />
    </div>
  )
}

export default App
